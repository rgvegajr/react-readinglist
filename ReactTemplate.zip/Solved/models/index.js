module.exports = {
  Book: require("./book")
};
